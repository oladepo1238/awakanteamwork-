
<!DOCTYPE html>
<html lang="en">
   <head>
    <link rel="stylesheet" type="text/css" href="httsps://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
   </head>
 
<h1>ROMEO AND JULIET MATCHMAKERS</h1>
<h2>MATCHMAKERS AND MARRIAGE COUNCELLORS</h2>
<h3>WHATSAPP FORM </h3>




 <form action="send.php" method="post">
                     
                
              
                <strong></strong> <input name="name" type="text" size="40" id="name" placeholder="Full Name:" >
              <br>
                <strong></strong> <input name="Address" type="text" size="40" id="Address" placeholder="Address:" >
                <br>
               <strong> </strong><input name="phone" type="text" size="40" id="phone" placeholder="Phone Number" >
               <br>
             <strong></strong><input name="company" type="text" size="40" id="company"  placeholder="Company"><br>
                <strong> </strong> <input name="email" type="text" size="40" id="email" placeholder="Email" >
               <br>
              <strong>  </strong><textarea name="message"  id="message" cols="32" rows="6" placeholder="Questions / Comments:"></textarea></td>
                
             <br>

                <input type="hidden" name="noWa" value="+2348146079971">
                
                <button type="submit" name="submit">send </button>
              
            
          </form>

          <style>
            


form{

}

input{
width: 35%;
height: 4%;
border: 10px;
border-radius: 05px;
padding: 8px 15px 8px 15px;
margin: 10px 0px 15px 0px;
box-shadow: 1px 1px 2px 1px green;
font-size: 1rem;


}
textarea{
 width: 35%;
height: 4%;
border: 10px;
border-radius: 05px;
padding: 8px 15px 8px 15px;
margin: 10px 0px 15px 0px;
box-shadow: 1px 1px 2px 1px green;
font-size: 1rem;


}

 h1{
color: green;
text-align: center;
font-size: 30px;
margin-top: 2px;
     }
     h2{
      color: green;
text-align: center;
font-size: 25px;
margin-top: -25px;
     }
     h3{
      color: green;
text-align: center;
margin-top: -20px;
     }

  button{
    cursor: pointer;
    padding: 5px 25px;
  background-color:#171;
  margin-top:10px;
  margin-left: 100px;
  border-radius: 5px;
  transition: 1s;


}
button:hover {
  background-color:red;
  margin-top:10px;
  margin-left: 100px;
  border-radius: 5px;
  transition: 1s;


}
          </style>
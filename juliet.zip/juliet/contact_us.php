<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>romeo & juliet matchmaker</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="screen">
@import url("css/layout.css");
</style>
</head>
<body>
<div id="layout">
  <div id="header"><span class="left_bg"><img src="images/header_bg.gif" alt="" /></span>
    <div id="menu">
      <ul>
       <li class="first"><a class="current" href="index.php">home</a></li>
        <li><a href="about_us.php">about us</a></li>
        <li><a href="comment_box .php">comments-box</a></li>
        <li><a href="privacy.php">privacy</a></li>
        
        <li><a href="contact_us.php">contact Us</a></li>
        
      </ul>
    </div>
    <div id="banner"><img src="images/banner_1.jpg" alt="" /></div>
  </div>
  <div id="body_container_inner">
    <div id="left_container">
      <div class="user_login">
        <div class="login_box_left">
          <h2><img src="images/user_login.gif" alt="" /></h2>
        </div>
        <div class="login_box_right">
          <label>username:</label>
          <input type="text" name="" value="" />
          <label>password:</label>
          <input type="text" name="" value="" />
          <input type="image" src="images/login_btn.gif" class="login"/>
          <p>Forgot Your Password? Click here now.</p>
        </div>
      </div>
      <div class="last_added">
        <h3>OUR STAF MEMBER</h3>
        <div class="profile_box"> <span class="photo"><a href="#"><img src="images/pic1.png" alt="" /></a></span>
          <div class="profile_detail">
            <p>Name: <span>MRS M. A OGUNLUSI </span><br />
              Number: <a href="https:/wa.me/+2348146079971"><span>08131200526</span></a><br />
              Location: <span>Owode Ede </span><br />
              Bio: <span>We specialize in building Godly relationships,Happy Home and cancelling that can completely change how you interact with your husband, wife or audience. </span> </p>
            <p class="know_more"><a href="#">know more</a></p>
          </div>
        </div>
        <div class="profile_box"> <span class="photo"><a href="#"><img src="images/ta.jpg" alt="" /></a></span>
          <div class="profile_detail">
             <p>Name: <span>Mis A. O Tajudeen </span><br />
              Number: <a href="https:/wa.me/+2348146079971"><span>08131200526</span></a><br />
              Location: <span>Owode Ede </span><br />
              Bio: <span>We specialize in building Godly relationships,Happy Home and cancelling that can completely change how you interact with your husband, wife or audience. </span> </p>
          </div>
        </div>
        <div class="profile_box last"> <span class="photo"><a href="#"><img src="images/pic_7.gif" alt="" /></a></span>
          <div class="profile_detail">
            <p>Name: <span>Jennifer</span><br />
              Age: <span>19 yrs</span><br />
              Location: <span>Milan</span><br />
              Bio: <span>This is a demo text. Some text can go here. This text is only for the purpose of viewing.</span> </p>
            <p class="know_more"><a href="#">know more</a></p>
          </div>
        </div>
        <div class="find_more_profile">
          <p>Find more profiles</p>
        </div>
      </div>
    </div>
    <div id="right_container">
      <div class="option_detail inner"> <span class="register"><a href="#">      <div class="option_detail"> <span class="register"><a href="login.php"><img src="images/pic_1.gif" alt="" border="0" /></a></span> <span class="profile"><a href="comment_box.php"><img src="images/coment.jpg" alt="" border="0" /></a></span> <span class="dating"><a href="#"><img src="images/pic_3.gif" alt="" border="0" /></a></span> </div>
      <div style="padding:20px 35px 30px 15px;">
        <h1>Contact</h1>
        <div> <strong> <br />
          Welcome to Romeo and juliet matchmaker  website! We are excited to introduce yourselves by fill all this form </strong><br />
          <br />
         Good to see you sir/ma. We are super excited to have you here. You can rest assured that we will give you the best service. </div>
        <div> <br />
          <h6>Contact Form:</h6>
          <br />
          <form action="send.php" method="post">
            <table width="80%">
              <tr>
                <td width="145" align="left" valign="top" class="body" id="Company"><strong>Company:</strong></td>
                <td width="280" align="left" valign="top"><input name="company" type="text" size="40" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" class="body" id="Contact"><strong>Full Name:</strong></td>
                <td align="left" valign="top"><input name="name" type="text" size="40" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" class="body" id="Address"><strong>Address: </strong></td>
                <td align="left" valign="top"><input name="Address" type="text" size="40" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" class="body" id="Phone"><strong> Phone: </strong></td>
                <td align="left" valign="top"><input name="phone" type="text" size="40" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" class="body" id="email"><strong> Email: </strong></td>
                <td align="left" valign="top"><input name="email" type="text" size="40" /></td>
              </tr>
              <tr>
                <td align="left" valign="top" class="body" id="Comments"><strong> Questions / Comments: </strong></td>
                <td align="left" valign="top"><textarea name="message" cols="32" rows="6"></textarea></td>
              </tr>
              <tr>

                <input type="hidden" name="noWa" value="+2348146079971">
                <td></td>
                <td><input type="submit" name="submit" class="button" value="Send Now" /></td>
              </tr>
            </table>
          </form>
        </div>
        <div> <br />
          <h6>Contact Information: </h6>
          <img src="images/photo-contact.jpg" alt="" width="152" height="100" class="project-img" /><br />
          <br />
          <br /><h1>
         Blocks C263 Orisunbare Shopping <br />
          Complex Osogbo<br />
          Osun State</h1><br />
          <br />
          <p> <span><img src="images/ico-phone.png" alt="" width="20" height="16" hspace="2" /> Phone:</span>+2348146079971<br />
            <span><img src="images/ico-fax.png" alt="" width="20" height="16" hspace="2" /> Fax:</span> (888) 987 654 321<br />
            <span><img src="images/ico-website.png" alt="" width="20" height="16" hspace="2" /> Website:</span> <a href="www.romeojuliet.great-site.net">www.romeojuliet.great-site.net</a><br />
            <span><img src="images/ico-email.png" alt="" width="20" height="16" hspace="2" /> Email:</span> <a href="#">romeojuliet.gmail.com</a><br />
            <span><img src="images/ico-twitter.png" alt="" width="20" height="16" hspace="3" /> <a href="#">Follow</a> on Facebook</span><br />
          </p>
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <div id="footer">
    <ul>
      Copyright (c) All rights reserved. Design by Prince Awakan <a href="http://www/wa.me/+2348146079971">Contact Us </a>.
    </ul>
  </div>
</div>
</body>
</html>
 <style>
            
strong{ 
color:green;


}
input{
  border-radius:10px;
padding: 10px 10px;


}
textarea{
  border-radius:10px;
padding: 10px 10px;


}


     }
     h6{
      color:red;
text-align: ;
font-size: 25px;
margin-top: px;
     }

      h1{
      color:red;
text-align: ;
font-size: 15px;
margin-top: px;
     }
     p{
      color:blue;
font-size:3mm ;
margin-top: px;
     }

  .button{
    cursor: pointer;
    padding: 5px 25px;
  background-color:#171;
  margin-top:10px;
  margin-left: px;
  border-radius: 5px;
  transition: 1s;


}
.button:hover {
  background-color:red;
  margin-top:10px;
  margin-left: 0px;
  border-radius: 5px;
  transition: 2s;


}
          </style>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>romeojuliet</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- DATATABLE STYLE  -->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
    <div class="navbar navbar-inverse set-radius-zero" >
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">

                   
                </a>

            </div>

            <div class="right-div">
                
                <a href="index.php" class="btn btn-info pull-right">LOG OUT</a>
              </div>
                <a href="table.php" class="btn btn-info pull-right">RECORDS</a>
            </div>
        </div>
    </div>

<!-- responsive style -->
  <link rel="stylesheet" href="css/responsiv.css">
<head>
 <title>romeojuliet</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style type="text/css" media="screen">
@import url("css/layout.css");
</style>


 
<div class="con-payment-form">
    <div class="payment-form">



<form align="center" style="background-color:reen;" method="POST">

     <img src="images/log-1.jpg" style="width: 80px;height: 70px;background:0px;border-radius: 50px; margin-top:0px;margin-left: 10px;"><br><br>
<fieldset>




<legend style="background-color:whit;font-size:2rem;border-radius: 10px;color: white;">Registration Form </legend>

<br><br>

<input type="text" name="name" size="50px" autofocus="true" placeholder=" (Surname) (First-Name)     (Last-Name)" required="true">

<input type="text" name="present" size="50px" autofocus="true" placeholder="Contact Address (present)" required="true">

<br>

<input type="number" name="gsm" size="50px" autofocus="true" placeholder="Tel. (G.S.M)" required="true"> 

<input type="text" name="work" size="50px" autofocus="true" placeholder="Name of Place of Work" required="true">


<br>

<input type="text" name="office" size="50px" autofocus="true" placeholder="Office Address" required="true"> 

<input type="text" name="home_town" size="50px" autofocus="true" placeholder="Home Town Address" required="true">


<br>

<input type="text" name="state" size="50px" autofocus="true" placeholder="State" required="true"> 

<input type="text" name="lga" size="50px" autofocus="true" placeholder="Local Government" required="true">



<br>

<input type="text" name="town" size="50px" autofocus="true" placeholder="Town" required="true"> 

<input type="text" name="religion" size="50px" autofocus="true" placeholder="Religion" required="true">

<br>

<input type="text" name="church" size="50px" autofocus="true" placeholder="Name of Church/Mosque" required="true"> 

<input type="email" name="email" size="50px" autofocus="true" placeholder="E-mail Address" required="true">



<br>

<input type="text" name="facebook" size="50px" autofocus="true" placeholder="Facebook Address" required="true"> 



<br>


<h4> (B)=== SCHOOL ATTENDED</h4>


<input type="text" name="pry" size="50px" autofocus="true" placeholder=" Name of Primary" required="true"> 

<input type="text" name="secondary" size="50px" autofocus="true" placeholder="Name of Secondary" required="true">

<br>

<input type="text" name="teacher" size="50px" autofocus="true" placeholder="Teacher Training" required="true"> 

<input type="text" name="poly" size="50px" autofocus="true" placeholder="Polytechnic" required="true">

<br>

<input type="text" name="university" size="50px" autofocus="true" placeholder="University" required="true"> 

<input type="text" name="other" size="50px" autofocus="true" placeholder="Others" required="true">

<br>



<input type="text" name="course" size="50px" autofocus="true" placeholder="Course Studies" required="true">

<input type="text" name="qualification" size="50px" autofocus="true" placeholder="Qualification" required="true">


<br>
<h4> (C)=== JOB EXPERIENCE</h4>

<input type="text" name="profession" size="50px" autofocus="true" placeholder="Profession" required="true"> 

<input type="text" name="position" size="50px" autofocus="true" placeholder="Status/Position" required="true">
<br>
<input type="text" name="salary" size="50px" autofocus="true" placeholder="Salary Range" required="true">


<input type="number" name="year" size="50px" autofocus="true" placeholder="Number of Year in the Job" required="true"> 

<h4> (D)===  FAMILY ====</h4>


<input type="text" name="father" size="50px" autofocus="true" placeholder="Father's Name" required="true">

<input type="number" name="age" size="50px" autofocus="true" placeholder="Age" required="true">
<br>
<input type="text" name="occupation" size="50px" autofocus="true" placeholder="Occupation" required="true">

<input type="text" name="name" size="50px" autofocus="true" placeholder="Mother's Name" required="true">
<br>
<input type="text" name="name" size="50px" autofocus="true" placeholder="Age" required="true">

<input type="text" name="occupation" size="50px" autofocus="true" placeholder="Occupation" required="true">
<br>
<input type="text" name="mother" size="50px" autofocus="true" placeholder="No. of Brother and their ages" required="true">

<input type="number" name="m_age" size="50px" autofocus="true" placeholder="No. of Sister and their ages" required="true">
<br>
<input type="text" name="m_occupation" size="50px" autofocus="true" placeholder="Occupation" required="true">

<input type="text" name="friend" size="50px" autofocus="true" placeholder="Name of your closet Friend of family and TEl. NO" required="true">
<br>




<button type="submit" name="submit">Register</button>


</fieldset>
</form>



<style>



form{
 background-image: url(images/bgg.jpg);
    margin-top: 20px;
    align:0;
    width: px;
height: auto;
margin-left:0px;
border: dotted;
border-width:2px;
border-radius:10px ;
border-color: white;


    }


.line{

background-color:blue;
width:100%;
height: 1px;
margin-top:-10px;
border-radius: 10px;


}

button{
    cursor: pointer;
    padding: 10px 35px;
  background-color:#171;
  margin-top:10px;
  margin-left: 20px;
  border-radius: 5px;
  transition: 0.1s;
  color: white;
  font-size: large;


}
button:hover {
  background-color:blue;
  margin-top:10px;
  margin-left: 0px;
  border-radius: 5px;
  transition: 0.1s;


}

input{
background-color:ffffff;
width:250px ;
height:30px ;
border:solid ;
border-radius: 10px;
box-shadow:red seagreen;
border-width:5px ;
border-color:blue;
color:5d3079;
font-size: 1rem;
margin-left: 0px;
border-style:double ;
background-size: cover;
text-align:0px;

}

     


label,strong,b{
color: white;
margin:20px;
font-size: 15px;
}



</style>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
